from Features.aimbot import start_aim_rcs
from Features.bhop import BHopProcess
from Features.glow import CS2GlowManager

def aim_process(shared_config):
    start_aim_rcs(shared_config)

def bhop_process(shared_config):
    bhop = BHopProcess(shared_config)
    bhop.run()

def glow_process(shared_config):
    glow_manager = CS2GlowManager(shared_config)
    glow_manager.run()