import os
import sys
import subprocess
import urllib.request
import zipfile
import shutil
import random
import string
import time
import base64
import logging

# Setup logger
logging.basicConfig(
    level=logging.INFO,
    format='[*] %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)

def random_string(length=8):
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))

VENV_DIR = random_string()
REQUIREMENTS_FILE = "requirements.txt"
PYMEOW_URL = "https://github.com/qb-0/pyMeow/releases/download/1.73.42/pyMeow-1.73.42.zip"
PYMEOW_ZIP = "pyMeow.zip"
PYMEOW_DIR = "pyMeow"

MAIN_SCRIPT = "GHaxV3_5.py"
LAUNCHER_FILE = "launcher.py"
FOLDERS_TO_OBFUSCATE = ["Features", "Process"]

def create_venv():
    if not os.path.exists(VENV_DIR):
        logging.info(f"Creating virtual environment: {VENV_DIR}")
        subprocess.run([sys.executable, "-m", "venv", VENV_DIR],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
    else:
        logging.info(f"Virtual environment already exists: {VENV_DIR}")

def install_requirements():
    pip_path = os.path.join(VENV_DIR, "Scripts", "pip.exe")
    logging.info("Installing requirements...")
    result = subprocess.run([pip_path, "install", "-r", REQUIREMENTS_FILE, "-q"],
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode != 0:
        logging.error(f"Failed to install pip requirements:\n{result.stderr}")
        sys.exit(1)
    logging.info("Requirements installed successfully.")

def is_pymeow_installed():
    pip_path = os.path.join(VENV_DIR, "Scripts", "pip.exe")
    result = subprocess.run([pip_path, "show", "pyMeow"],
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    return result.returncode == 0

def download_and_install_pymeow():
    if is_pymeow_installed():
        logging.info("pyMeow already installed.")
        return

    logging.info("Downloading pyMeow...")
    urllib.request.urlretrieve(PYMEOW_URL, PYMEOW_ZIP)

    logging.info("Extracting pyMeow...")
    with zipfile.ZipFile(PYMEOW_ZIP, 'r') as zip_ref:
        zip_ref.extractall(PYMEOW_DIR)

    pip_path = os.path.join(VENV_DIR, "Scripts", "pip.exe")
    logging.info("Installing pyMeow...")
    result = subprocess.run([pip_path, "install", "."], cwd=PYMEOW_DIR,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode != 0:
        logging.error(f"Failed to install pyMeow:\n{result.stderr}")
        sys.exit(1)

    os.remove(PYMEOW_ZIP)
    shutil.rmtree(PYMEOW_DIR)
    logging.info("pyMeow installed successfully.")

def get_py_files():
    files = [MAIN_SCRIPT]
    for folder in FOLDERS_TO_OBFUSCATE:
        for root, _, filenames in os.walk(folder):
            for f in filenames:
                if f.endswith(".py"):
                    files.append(os.path.join(root, f))
    logging.info(f"Collected {len(files)} Python files for obfuscation.")
    return files

def encode_file(path):
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode("ascii")

def module_name_from_path(path):
    path = os.path.splitext(path)[0]
    parts = path.replace("\\", "/").split("/")
    return ".".join(parts)

def generate_launcher():
    logging.info("Generating base64 launcher...")
    py_files = get_py_files()
    modules_b64 = {}
    for f in py_files:
        mod_name = module_name_from_path(f)
        b64 = encode_file(f)
        modules_b64[mod_name] = b64

    launcher_code = f'''\
import sys
import base64
import importlib.abc
import importlib.util

modules = {modules_b64!r}

class Base64Loader(importlib.abc.Loader):
    def __init__(self, name):
        self.name = name
    def create_module(self, spec):
        return None
    def exec_module(self, module):
        code_b64 = modules[self.name]
        code = base64.b64decode(code_b64).decode('utf-8')
        exec(code, module.__dict__)
    def get_code(self, fullname):
        code_b64 = modules[self.name]
        source = base64.b64decode(code_b64).decode('utf-8')
        return compile(source, "<string>", "exec")
    def get_source(self, fullname):
        code_b64 = modules[self.name]
        return base64.b64decode(code_b64).decode('utf-8')

class Base64Finder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path, target=None):
        if fullname in modules:
            return importlib.util.spec_from_loader(fullname, Base64Loader(fullname))
        return None

sys.meta_path.insert(0, Base64Finder())

if __name__ == "__main__":
    import runpy
    runpy.run_module("{module_name_from_path(MAIN_SCRIPT)}", run_name="__main__")
'''
    with open(LAUNCHER_FILE, "w", encoding="utf-8") as f:
        f.write(launcher_code)

    logging.info(f"Launcher generated: {LAUNCHER_FILE} with {len(modules_b64)} modules.")

def main():
    print(r"""
      .-_'''-.   .---.  .---.    ____     _____     __   
     '_( )_   \  |   |  |_ _|  .'  __ `.  \   _\   /  /  
    |(_ o _)|  ' |   |  ( ' ) /   '  \  \ .-./ ). /  '   
    . (_,_)/___| |   '-(_{;}_)|___|  /  | \ '_ .') .'    
    |  |  .-----.|      (_,_)    _.-`   |(_ (_) _) '     
    '  \  '-   .'| _ _--.   | .'   _    |  /    \   \    
     \  `-'`   | |( ' ) |   | |  _( )_  |  `-'`-'    \   
      \        / (_{;}_)|   | \ (_ o _) / /  /   \    \  
       `'-...-'  '(_,_) '---'  '.(_,_).' '--'     '----' 
    """)
    logging.info("Starting setup sequence...")

    # Run offset_update.py first to update offsets.py
    logging.info("Updating offsets by running Process.offset_update.py...")
    subprocess.run([sys.executable, "offset_update.py"], cwd="Process", check=True)

    time.sleep(random.uniform(0.5, 3))

    create_venv()
    install_requirements()
    download_and_install_pymeow()
    generate_launcher()

    python_exe = os.path.join(VENV_DIR, "Scripts", "python.exe")
    logging.info(f"Executing: {LAUNCHER_FILE}")
    subprocess.run([python_exe, LAUNCHER_FILE], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

if __name__ == "__main__":
    main()
