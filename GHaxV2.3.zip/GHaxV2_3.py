# seperated script into modules further
# Added aimbot & recoil control as well as lots of customization.
# Added Glow ESP
# Added cooldown to TriggerBot
# Added BHop (works very well)
# Added show FOV overlay for aimbot (seperate overlay window)
# Added process handler for client.dll
# Added hardcoded offsets (update using update_offsets.py)
# Added aimbot toggle bone, (I messed up bone indices, decided to add downward_offset instead of fixing (kek))
# Made offsets load locally instead of fetching from a2x's CS2 Dumper
# Made script to fully update Offsets module (offsets.py) - does fetch from a2x's CS2 Dumper.


import os
import sys
import time
import string
import ctypes
from random import uniform
from datetime import datetime
import threading
import math

import keyboard
import winsound
import requests
from requests import get
import pymem
import pymem.process
import pyMeow as pw_module
from pynput.mouse import Controller, Button
from win32gui import GetWindowText, GetForegroundWindow

from PyQt5.QtCore import Qt, QEvent, QTimer
from PyQt5.QtGui import QPixmap, QColor, QPainter, QPen, QBrush
from PyQt5.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QCheckBox,
    QPushButton,
    QLabel,
    QColorDialog,
    QFontDialog,
    QInputDialog,
    QMessageBox,
    QDialog,
    QSlider,
    QGroupBox,
    QScrollArea,
    QComboBox,
)

import multiprocessing
import time
import signal

from Process.offsets import Offsets
from Process.entity import Entity
from Process.process_handler import CS2Process


from Features.triggerbot import TriggerBot, SetTriggerKeyDialog
from Features.aimbot import start_aim_rcs
from Features.bhop import BHopProcess
from Features.glow import CS2GlowManager 

def aim_process(shared_config):
    start_aim_rcs(shared_config)

def bhop_process(shared_config):
    bhop = BHopProcess(shared_config)
    bhop.run()

def glow_process(shared_config):
    glow_manager = CS2GlowManager(shared_config)
    glow_manager.run()

def main():
    multiprocessing.freeze_support()
    manager = multiprocessing.Manager()
    shared_config = manager.Namespace()

    # === OPTIMAL AIM CONFIG ===
    shared_config.enabled = False
    shared_config.stop = False
    shared_config.bhop_enabled = True
    shared_config.glow = False

    shared_config.FOV = 4.0
    shared_config.smooth_base = 0.12
    shared_config.smooth_var = 0.00
    shared_config.rcs_smooth_base = 0.12
    shared_config.rcs_smooth_var = 0.03
    shared_config.rcs_scale = 2.6
    shared_config.stabilize_shots = 3
    shared_config.max_entities = 64
    shared_config.target_switch_delay = 0.2
    shared_config.aim_start_delay = 0.06
    shared_config.downward_offset = 62
    shared_config.target_bone_name = "head"
    shared_config.DeathMatch = False

    aim_p = multiprocessing.Process(target=aim_process, args=(shared_config,), name="AimProcess")
    bhop_p = multiprocessing.Process(target=bhop_process, args=(shared_config,), name="BHopProcess")
    glow_p = multiprocessing.Process(target=glow_process, args=(shared_config,), name="GlowProcess")

    aim_p.start()
    bhop_p.start()
    glow_p.start()

    app = QApplication([])

    cs2_process = CS2Process()
    try:
        cs2_process.initialize()
    except RuntimeError as e:
        print(f"Failed to initialize CS2 process: {e}")
        shared_config.stop = True
        shared_config.bhop_enabled = False
        shared_config.glow = False
        aim_p.terminate()
        bhop_p.terminate()
        glow_p.terminate()
        manager.shutdown()
        return

    program = Program(shared_config, cs2_process=cs2_process)

    def signal_handler(sig, frame):
        print("[*] Signal received, stopping...")
        shared_config.stop = True
        shared_config.bhop_enabled = False
        shared_config.glow = False

    signal.signal(signal.SIGINT, signal_handler)

    try:
        program.Run()
        app.exec_()
    except Exception as e:
        print(f"[!] Exception in main: {e}")
    finally:
        shared_config.stop = True
        shared_config.bhop_enabled = False
        shared_config.glow = False

        for p in (aim_p, bhop_p, glow_p):
            if p.is_alive():
                p.join(timeout=3)
                if p.is_alive():
                    print(f"[!] Force terminating process: {p.name}")
                    p.terminate()

        manager.shutdown()

        print("[*] Shutdown complete.")

        
def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and PyInstaller """
    if hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)

class FOVOverlay(QWidget):
    def __init__(self, shared_config, color=(0, 255, 0, 150), thickness=3):
        super().__init__()
        self.shared_config = shared_config
        self.color = QColor(*color)
        self.thickness = thickness

        self.setWindowTitle("FOV Overlay")
        self.setWindowFlags(Qt.WindowStaysOnTopHint | Qt.FramelessWindowHint | Qt.WindowTransparentForInput)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_NoSystemBackground)

        screen = QApplication.primaryScreen().geometry()
        self.screen_width, self.screen_height = screen.width(), screen.height()
        self.center_x, self.center_y = self.screen_width // 2, self.screen_height // 2
        self.setGeometry(0, 0, self.screen_width, self.screen_height)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update)
        self.timer.start(16)  # ~60 FPS
        self.show()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        pen = QPen(self.color, self.thickness)
        painter.setPen(pen)

        aim_fov_deg = self.shared_config.FOV
        game_fov_deg = 90
        aspect_ratio = self.screen_height / self.screen_width
        fudge_factor = 1.0

        # Convert FOVs to radians
        game_fov_rad = math.radians(game_fov_deg)
        aim_fov_rad = math.radians(aim_fov_deg)
        vertical_fov_rad = 2 * math.atan(math.tan(game_fov_rad / 2) * aspect_ratio)

        radius_x = math.tan(aim_fov_rad / 2) / math.tan(game_fov_rad / 2) * (self.screen_width / 2)
        radius_y = math.tan(aim_fov_rad / 2) / math.tan(vertical_fov_rad / 2) * (self.screen_height / 2)
        radius_x *= fudge_factor
        radius_y *= fudge_factor

        # Draw ellipse
        painter.drawEllipse(
            int(self.center_x - radius_x),
            int(self.center_y - radius_y),
            int(radius_x * 2),
            int(radius_y * 2)
        )

class WallHack:
    BONE_POSITIONS = {
        "head": 6,
        "chest": 15,
        "left_hand": 10,
        "right_hand": 2,
        "left_leg": 23,
        "right_leg": 26,
    }

    BONE_CONNECTIONS = [
        (0, 2), (2, 4), (4, 5), (5, 6),
        (4, 8), (8, 9), (9, 10),
        (4, 13), (13, 14), (14, 15),
        (0, 22), (22, 23), (23, 24),
        (0, 25), (25, 26), (26, 27)
    ]

    def __init__(self, process, module):
        self.process = process
        self.module = module

        self.enabled = True
        self.watermark_enabled = True
        self.crosshair_enabled = False
        self.enemy_only_enabled = False
        self.team_only_enabled = False
        self.distance_esp_enabled = False
        self.box_esp_enabled = False
        self.healthbar_enabled = False
        self.health_esp_enabled = False
        self.name_esp_enabled = False
        self.line_esp_enabled = False
        self.head_esp_enabled = False
        self.skeletonesp = False
        self.bone_esp_enabled = False

        self.esp_font_settings = {"size": 10, "color": "cyan"}
        self.head_esp_shape = "square"
        self.head_esp_size = 10
        self.bone_esp_shape = "square"
        self.bone_esp_size = 5

        self.team_esp_color = "blue"
        self.box_esp_color = "red"
        self.head_esp_color = "yellow"
        self.line_color = "white"
        self.skeleton_esp_color = "orange"
        self.bone_esp_color = "yellow"
        self.box_background_color = "black"
        self.crosshair_color = "white"

    def GetLocalPlayerTeam(self):
        try:
            pawn = pw_module.r_int64(self.process, self.module + Offsets.dwLocalPlayerPawn)
            return pw_module.r_int(self.process, pawn + Offsets.m_iTeamNum) if pawn else None
        except:
            return None

    def ToggleFeature(self, attr, state):
        setattr(self, attr, state)

    def ToggleDistanceESP(self, state): self.ToggleFeature("distance_esp_enabled", state)
    def Toggle(self, state): self.ToggleFeature("enabled", state)
    def ToggleWatermark(self, state): self.ToggleFeature("watermark_enabled", state)
    def ToggleBoxESP(self, state): self.ToggleFeature("box_esp_enabled", state)
    def ToggleHealthBar(self, state): self.ToggleFeature("healthbar_enabled", state)
    def ToggleHealthESP(self, state): self.ToggleFeature("health_esp_enabled", state)
    def ToggleEnemyOnly(self, state): self.ToggleFeature("enemy_only_enabled", state)
    def ToggleTeamOnly(self, state): self.ToggleFeature("team_only_enabled", state)
    def ToggleNameESP(self, state): self.ToggleFeature("name_esp_enabled", state)
    def ToggleLineESP(self, state): self.ToggleFeature("line_esp_enabled", state)
    def ToggleHeadESP(self, state): self.ToggleFeature("head_esp_enabled", state)
    def ToggleSkeletonESP(self, state): self.ToggleFeature("skeletonesp", state)
    def ToggleBoneESP(self, state): self.ToggleFeature("bone_esp_enabled", state)
    def ToggleCrosshair(self, state): self.ToggleFeature("crosshair_enabled", state)

    def ChangeColor(self, attr):
        color = QColorDialog.getColor()
        if color.isValid():
            setattr(self, attr, color.name())

    def ChangeBoxESPColor(self): self.ChangeColor("box_esp_color")
    def ChangeTeamESPColor(self): self.ChangeColor("team_esp_color")
    def ChangeESPFontColor(self): self.esp_font_settings["color"] = QColorDialog.getColor().name()
    def ChangeLineESPColor(self): self.ChangeColor("line_color")
    def ChangeHeadESPColor(self): self.ChangeColor("head_esp_color")
    def ChangeSkeletonESPColor(self): self.ChangeColor("skeleton_esp_color")
    def ChangeBoneESPColor(self): self.ChangeColor("bone_esp_color")
    def ChangeBoxBackgroundColor(self): self.ChangeColor("box_background_color")
    def ChangeCrosshairColor(self): self.ChangeColor("crosshair_color")

    def ChangeSize(self, attr, title, label, default):
        size, ok = QInputDialog.getInt(None, title, label, value=default)
        if ok:
            setattr(self, attr, size)

    def ChangeHeadESPSize(self): self.ChangeSize("head_esp_size", "Head ESP Size", "Enter Head ESP Size:", self.head_esp_size)
    def ChangeBoneESPSize(self): self.ChangeSize("bone_esp_size", "Bone ESP Size", "Enter Bone ESP Size:", self.bone_esp_size)
    def ChangeESPFontSize(self): self.esp_font_settings["size"], _ = QInputDialog.getInt(None, "Font Size", "Enter Font Size:", value=self.esp_font_settings["size"])

    def ChangeShape(self, attr, title):
        items = ("square", "circle")
        item, ok = QInputDialog.getItem(None, title, f"Select {title}:", items, 0, False)
        if ok and item:
            setattr(self, attr, item.lower())

    def ChangeHeadESPShape(self): self.ChangeShape("head_esp_shape", "Head ESP Shape")
    def ChangeBoneESPShape(self): self.ChangeShape("bone_esp_shape", "Bone ESP Shape")

    def RenderBoneESP(self, entity, matrix):
        if not self.bone_esp_enabled:
            return

        for bone_name, bone_index in self.BONE_POSITIONS.items():
            bone_pos = entity.BonePos(bone_index)
            try:
                screen = pw_module.world_to_screen(matrix, bone_pos, 1)
            except:
                continue

            if screen:
                x, y = screen["x"], screen["y"]
                size = self.bone_esp_size
                color = pw_module.get_color(self.bone_esp_color)
                if self.bone_esp_shape == "square":
                    pw_module.draw_rectangle_lines(x - size / 2, y - size / 2, size, size, color, 1)
                elif self.bone_esp_shape == "circle":
                    pw_module.draw_circle_lines(x, y, size / 2, color)


    def ChangeBoxBackgroundColor(self):
        color_dialog = QColorDialog()
        color = color_dialog.getColor()
        if color.isValid():
            self.box_background_color = color.name()

    def ToggleCrosshair(self, state):
        self.crosshair_enabled = state

    def ChangeCrosshairColor(self):
        color_dialog = QColorDialog()
        color = color_dialog.getColor()
        if color.isValid():
            self.crosshair_color = color.name()

    def resolve_entity(self, entity_list_base, index, local_controller):
        try:
            entity_size = 0x78
            high_index = (index & 0x7FFF) >> 9
            low_index = index & 0x1FF

            entry_ptr = pw_module.r_int64(self.process, entity_list_base + 8 * high_index + 16)
            if not entry_ptr:
                return None

            controller = pw_module.r_int64(self.process, entry_ptr + entity_size * low_index)
            if not controller or controller == local_controller:
                return None

            player_pawn_handle = pw_module.r_int64(self.process, controller + Offsets.m_hPlayerPawn)
            if not player_pawn_handle:
                return None

            pawn_entry_ptr = pw_module.r_int64(self.process, entity_list_base + 8 * ((player_pawn_handle & 0x7FFF) >> 9) + 16)
            if not pawn_entry_ptr:
                return None

            pawn = pw_module.r_int64(self.process, pawn_entry_ptr + entity_size * (player_pawn_handle & 0x1FF))
            if not pawn:
                return None

            return Entity(controller, pawn, self.process)
        except:
            return None


    def GetEntities(self):
        entity_list = pw_module.r_int64(self.process, self.module + Offsets.dwEntityList)
        local_controller = pw_module.r_int64(self.process, self.module + Offsets.dwLocalPlayerController)

        if not entity_list or not local_controller:
            return

        for i in range(1, 65):
            entity = self.resolve_entity(entity_list, i, local_controller)
            if entity:
                yield entity

    def Render(self):
        if self.watermark_enabled:
            color_text = pw_module.get_color("white")
            color_bg = pw_module.get_color("black")
            size = 20
            text1, text2 = "GHax", "Made By Cr0mb"
            width = max(pw_module.measure_text(text1, size), pw_module.measure_text(text2, size)) + 20
            pw_module.draw_rectangle(10, 10, width, 60, color_bg)
            pw_module.draw_text(text1, 20, 20, size, color_text)
            pw_module.draw_text(text2, 20, 40, 15, color_text)

        if not self.enabled:
            return

        local_pawn = pw_module.r_int64(self.process, self.module + Offsets.dwLocalPlayerPawn)
        if not local_pawn:
            return

        local_team = self.GetLocalPlayerTeam()
        if local_team is None:
            return

        matrix = pw_module.r_floats(self.process, self.module + Offsets.dwViewMatrix, 16)
        if not matrix or len(matrix) < 16:
            return

        def draw_centered(text, x, y, size, color):
            if text and x is not None and y is not None:
                text_width = pw_module.measure_text(text, size)
                pw_module.draw_text(text, x - text_width / 2, y, size, color)

        local_pos = pw_module.r_vec3(self.process, local_pawn + Offsets.m_vOldOrigin)
        if not local_pos:
            return

        font_size = self.esp_font_settings["size"]
        font_color = pw_module.get_color(self.esp_font_settings["color"])

        for entity in self.GetEntities():
            try:
                health = entity.Health()
                if health <= 0 or not entity.Wts(matrix):
                    continue

                team = entity.Team()
                if team is None or (self.enemy_only_enabled and team == local_team) or (self.team_only_enabled and team != local_team):
                    continue

                head_y = entity.headPos2d["y"]
                head_x = entity.headPos2d["x"]
                feet_y = entity.pos2d["y"]
                height = feet_y - head_y
                if height <= 0:
                    continue

                width = height / 2
                center = width / 2
                box_x, box_y = head_x - center, head_y - center / 2
                box_h = height + center / 2
                color = pw_module.get_color(self.box_esp_color if team == 2 else self.team_esp_color)

                pos = entity.Pos()

                if self.distance_esp_enabled:
                    dx, dy, dz = local_pos["x"] - pos["x"], local_pos["y"] - pos["y"], local_pos["z"] - pos["z"]
                    dist = (dx*dx + dy*dy + dz*dz) ** 0.5 / 10
                    feet_2d = pw_module.world_to_screen(matrix, pos, 1)
                    if feet_2d:
                        draw_centered(f"{int(dist)}m", feet_2d["x"], feet_2d["y"] - 10, font_size, font_color)

                if self.box_esp_enabled:
                    fill = pw_module.fade_color(pw_module.get_color(self.box_background_color), 0.5)
                    pw_module.draw_rectangle(box_x, box_y, width, box_h, fill)
                    pw_module.draw_rectangle_lines(box_x, box_y, width, box_h, color, 0.8)

                if self.healthbar_enabled:
                    bar_height = height * (health / 90)
                    bar_x = head_x - center - 5
                    bar_y = head_y + height
                    hp_color = pw_module.get_color("green" if health > 66 else "yellow" if health > 33 else "red")
                    pw_module.draw_rectangle(bar_x - 1, bar_y - bar_height - 1, 5, bar_height + 2, pw_module.get_color("black"))
                    pw_module.draw_rectangle(bar_x, bar_y - bar_height, 3, bar_height, hp_color)

                if self.health_esp_enabled:
                    pw_module.draw_text(f"HP: {health}%", head_x + center + 2, head_y - center + 10, font_size, font_color)

                if self.name_esp_enabled:
                    draw_centered(entity.Name(), head_x, head_y - center - 10, font_size, font_color)

                if self.line_esp_enabled:
                    cx = pw_module.get_screen_width() / 2
                    cy = pw_module.get_screen_height()
                    pw_module.draw_line(cx, cy, head_x, head_y, pw_module.get_color(self.line_color))

                if self.head_esp_enabled:
                    size = self.head_esp_size
                    color = pw_module.get_color(self.head_esp_color)
                    if self.head_esp_shape == "square":
                        pw_module.draw_rectangle_lines(head_x - size/2, head_y - size/2, size, size, color, 1)
                    elif self.head_esp_shape == "circle":
                        pw_module.draw_circle_lines(head_x, head_y, size/2, color)

                if self.bone_esp_enabled:
                    self.RenderBoneESP(entity, matrix)

                if self.skeletonesp:
                    skel_color = pw_module.get_color(self.skeleton_esp_color)
                    for bone_a, bone_b in self.BONE_CONNECTIONS:
                        try:
                            a = pw_module.world_to_screen(matrix, entity.BonePos(bone_a), 1)
                            b = pw_module.world_to_screen(matrix, entity.BonePos(bone_b), 1)
                            if a and b:
                                pw_module.draw_line(a["x"], a["y"], b["x"], b["y"], skel_color)
                        except Exception:
                            continue

            except Exception:
                continue

        if self.crosshair_enabled:
            cx, cy = pw_module.get_screen_width() / 2, pw_module.get_screen_height() / 2
            size = 10
            color = pw_module.get_color(self.crosshair_color)
            pw_module.draw_line(cx - size, cy, cx + size, cy, color)
            pw_module.draw_line(cx, cy - size, cx, cy + size, color)

        pw_module.end_drawing()

class NoWheelSlider(QSlider):
    def wheelEvent(self, event):
        event.ignore()

class Program:
    def __init__(self, shared_config, cs2_process=None):
        self.shared_config = shared_config

        try:
            self.fps = 144

            if cs2_process is None:
                self.cs2 = CS2Process()
                self.cs2.initialize()
            else:
                self.cs2 = cs2_process

            self.process = self.cs2.process
            self.module = self.cs2.module_base

            self.wall = WallHack(self.process, self.module)
            self.triggerbot = None
            self.trigger_key = None
            self.trigger_team = False
            self.fov_overlay = None
            self.fov_overlay_enabled = False
            self.create_gui()

        except Exception as e:
            exit(f"Error: Enable only after opening Counter Strike 2\nDetails: {e}")

    def create_gui(self):
        self.window = QWidget()
        self.window.setWindowTitle("GHax V2.3 By Cr0mb")
        self.window.setGeometry(100, 100, 460, 500)
        self.window.setStyleSheet("background-color: #2C2F33; color: white; font-family: Segoe UI; font-size: 12px;")

        main_layout = QVBoxLayout()

        def create_top_row():
            layout = QHBoxLayout()

            info_layout = QVBoxLayout()
            info = [
                "The toggle key for the aimbot is '['",
                "The toggle key for the aim bone is ']'"
            ]
            label_style = "color: #7289DA; font-weight: bold; font-size: 14px;"
            for text in info:
                label = QLabel(text)
                label.setStyleSheet(label_style)
                label.setAlignment(Qt.AlignLeft)
                info_layout.addWidget(label)

            layout.addLayout(info_layout)
            return layout


        def create_esp_group():
            esp_group = QGroupBox("ESP Features")
            esp_layout = QVBoxLayout()
            esp_features = [
                ("Watermark", self.toggle_watermark, getattr(self.wall, 'watermark_enabled', False)),
                ("Box ESP", self.toggle_box_esp, False),
                ("Line ESP", self.toggle_line_esp, False),
                ("Skeleton ESP", self.toggle_skeleton_esp, False),
                ("Bone ESP", self.toggle_bone_esp, getattr(self.wall, 'bone_esp_enabled', False)),
                ("Head ESP", self.toggle_head_esp, False),
                ("Name ESP", self.toggle_name_esp, False),
                ("Health ESP", self.toggle_health_esp, False),
                ("Health Bar", self.toggle_healthbar, False),
                ("Distance ESP", self.toggle_distance_esp, False),
                ("Enemy Only", self.toggle_enemy_only, getattr(self.wall, 'enemy_only_enabled', False)),
                ("Team Only", self.toggle_team_only, getattr(self.wall, 'team_only_enabled', False)),
            ]
            for label, func, state in esp_features:
                cb = QCheckBox(label)
                cb.setChecked(state)
                cb.stateChanged.connect(func)
                esp_layout.addWidget(cb)
            esp_group.setLayout(esp_layout)
            return esp_group

        def create_triggerbot_group():
            tg = QGroupBox("Triggerbot")
            layout = QVBoxLayout()

            def mk_checkbox(text, state_attr, toggle_func):
                cb = QCheckBox(text)
                cb.setChecked(getattr(self.shared_config, state_attr, False))
                cb.stateChanged.connect(toggle_func)
                return cb

            trigger_cb = mk_checkbox("Triggerbot", "triggerbot_enabled", self.toggle_triggerbot)
            teammate_cb = mk_checkbox("Shoot Teammates", "shoot_teammates", self.toggle_shoot_teammates)
            trigger_key_btn = QPushButton("Set Trigger Key")
            trigger_key_btn.clicked.connect(self.set_trigger_key)

            cooldown_val = getattr(self.shared_config, 'triggerbot_cooldown', 0.8)
            cooldown_label = QLabel(f"Triggerbot Cooldown (s): {cooldown_val:.1f}")

            cooldown_slider = NoWheelSlider(Qt.Horizontal)
            cooldown_slider.setMinimum(1)
            cooldown_slider.setMaximum(50)
            cooldown_slider.setValue(int(cooldown_val * 10))

            def on_cooldown_change(val):
                secs = val / 10
                cooldown_label.setText(f"Triggerbot Cooldown (s): {secs:.1f}")
                self.shared_config.triggerbot_cooldown = secs

            cooldown_slider.valueChanged.connect(on_cooldown_change)

            for w in (trigger_cb, teammate_cb, trigger_key_btn, cooldown_label, cooldown_slider):
                layout.addWidget(w)

            tg.setLayout(layout)
            return tg

        def create_crosshair_group():
            g = QGroupBox("Crosshair")
            l = QVBoxLayout()
            cb = QCheckBox("Crosshair")
            cb.setChecked(getattr(self.shared_config, 'crosshair_enabled', False))
            cb.stateChanged.connect(self.toggle_crosshair)
            btn = QPushButton("Change Crosshair Color")
            btn.clicked.connect(self.change_crosshair_color)
            l.addWidget(cb)
            l.addWidget(btn)
            g.setLayout(l)
            return g

        def create_color_group():
            g = QGroupBox("Style & Colors")
            l = QVBoxLayout()
            buttons = [
                ("Box Background Color", self.wall.ChangeBoxBackgroundColor),
                ("Box Enemy Color", self.wall.ChangeBoxESPColor),
                ("Box Team Color", self.wall.ChangeTeamESPColor),
                ("Skeleton ESP Color", self.wall.ChangeSkeletonESPColor),
                ("Change Font Color", self.wall.ChangeESPFontColor),
                ("Change Font Size", self.wall.ChangeESPFontSize),
                ("Bone ESP Size", self.wall.ChangeBoneESPSize),
                ("Bone ESP Shape", self.wall.ChangeBoneESPShape),
                ("Bone ESP Color", self.wall.ChangeBoneESPColor),
                ("Line Color", self.wall.ChangeLineESPColor),
                ("Head ESP Color", self.wall.ChangeHeadESPColor),
                ("Head ESP Size", self.wall.ChangeHeadESPSize),
                ("Head ESP Shape", self.wall.ChangeHeadESPShape),
            ]
            for text, cbk in buttons:
                btn = QPushButton(text)
                btn.clicked.connect(cbk)
                l.addWidget(btn)
            g.setLayout(l)
            return g

        def create_misc_group():
            g = QGroupBox("Misc")
            l = QVBoxLayout()
            lbl_warn = QLabel("⚠️ Warning: Changing FOV writes directly to game memory.")
            lbl_warn.setWordWrap(True)
            lbl_warn.setStyleSheet("color: #FF5555; font-weight: bold;")
            l.addWidget(lbl_warn)
            
            glow_warn = QLabel("⚠️ Warning: Enabling Glow writes directly to game memory.")
            glow_warn.setWordWrap(True)
            glow_warn.setStyleSheet("color: #FF5555; font-weight: bold;")
            l.addWidget(glow_warn)

            fov_val = getattr(self.shared_config, 'game_fov', 90)
            lbl_fov = QLabel(f"FOV: {fov_val}")
            lbl_fov.setAlignment(Qt.AlignCenter)
            l.addWidget(lbl_fov)

            slider = NoWheelSlider(Qt.Horizontal)
            slider.setMinimum(50)
            slider.setMaximum(179)
            slider.setValue(fov_val)
            l.addWidget(slider)

            def on_fov_change(v):
                lbl_fov.setText(f"FOV: {v}")
                try:
                    ctrl = pw_module.r_int64(self.process, self.module + Offsets.dwLocalPlayerController)
                    if ctrl:
                        pw_module.w_int(self.process, ctrl + Offsets.m_iDesiredFOV, v)
                    self.shared_config.game_fov = v
                except Exception as e:
                    print(f"Error setting FOV: {e}")

            slider.valueChanged.connect(on_fov_change)

            bhop_cb = QCheckBox("Enable Bhop")
            bhop_cb.setChecked(getattr(self.shared_config, 'bhop_enabled', False))
            bhop_cb.stateChanged.connect(lambda s: setattr(self.shared_config, 'bhop_enabled', s == Qt.Checked))
            l.addWidget(bhop_cb)

            glow_cb = QCheckBox("Enable Glow")
            glow_cb.setChecked(getattr(self.shared_config, 'glow', True))  # Default True if not set
            def on_glow_toggle(state):
                self.shared_config.glow = (state == Qt.Checked)
                print(f"[GUI] Glow {'ENABLED' if self.shared_config.glow else 'DISABLED'}")
            glow_cb.stateChanged.connect(on_glow_toggle)
            l.addWidget(glow_cb)

            g.setLayout(l)
            return g



        def create_aimbot_group():
            aimbot_group = QGroupBox("Aimbot Settings")
            aimbot_layout = QVBoxLayout()

            # Enable Aimbot
            aimbot_enable_checkbox = QCheckBox("Enable Aimbot")
            aimbot_enable_checkbox.setChecked(self.shared_config.enabled)

            def on_aimbot_toggle(state):
                self.shared_config.enabled = (state == Qt.Checked)
                print(f"[GUI] Aimbot {'ENABLED' if self.shared_config.enabled else 'DISABLED'}")

            aimbot_enable_checkbox.stateChanged.connect(on_aimbot_toggle)
            aimbot_layout.addWidget(aimbot_enable_checkbox)


            # DeathMatch toggle
            deathmatch_checkbox = QCheckBox("DeathMatch (shoot teammates)")
            deathmatch_checkbox.setChecked(self.shared_config.DeathMatch)

            def on_deathmatch_toggle(state):
                self.shared_config.DeathMatch = (state == Qt.Checked)
                print(f"[GUI] DeathMatch {'ENABLED' if self.shared_config.DeathMatch else 'DISABLED'}")

            deathmatch_checkbox.stateChanged.connect(on_deathmatch_toggle)
            aimbot_layout.addWidget(deathmatch_checkbox)

            # Show FOV Overlay Checkbox
            fov_overlay_cb = QCheckBox("Show FOV Overlay")
            fov_overlay_cb.setChecked(getattr(self, 'fov_overlay_enabled', False))

            def on_fov_overlay_toggle(state):
                if state == Qt.Checked:
                    if not hasattr(self, 'fov_overlay') or not self.fov_overlay:
                        self.fov_overlay = FOVOverlay(self.shared_config)
                    self.fov_overlay.show()
                    self.fov_overlay_enabled = True
                    print("[GUI] FOV Overlay ENABLED")
                else:
                    if hasattr(self, 'fov_overlay') and self.fov_overlay:
                        self.fov_overlay.hide()
                    self.fov_overlay_enabled = False
                    print("[GUI] FOV Overlay DISABLED")

            fov_overlay_cb.stateChanged.connect(on_fov_overlay_toggle)
            aimbot_layout.addWidget(fov_overlay_cb)


            # Aimbot FOV Slider
            aimbot_fov_label = QLabel(f"Aimbot FOV: {self.shared_config.FOV:.1f}")
            aimbot_fov_slider = NoWheelSlider(Qt.Horizontal)
            aimbot_fov_slider.setMinimum(1)
            aimbot_fov_slider.setMaximum(30)
            aimbot_fov_slider.setValue(int(self.shared_config.FOV))
            aimbot_fov_slider.valueChanged.connect(lambda v: (
                setattr(self.shared_config, 'FOV', float(v)),
                aimbot_fov_label.setText(f"Aimbot FOV: {v}"),
                self.fov_overlay.update() if getattr(self, 'fov_overlay_enabled', False) and getattr(self, 'fov_overlay', None) else None
            ))
            aimbot_layout.addWidget(aimbot_fov_label)
            aimbot_layout.addWidget(aimbot_fov_slider)

            # Smooth Base Slider
            aimbot_smooth_label = QLabel(f"Aimbot Smooth Base: {self.shared_config.smooth_base:.2f}")
            aimbot_smooth_slider = NoWheelSlider(Qt.Horizontal)
            aimbot_smooth_slider.setMinimum(1)
            aimbot_smooth_slider.setMaximum(100)
            aimbot_smooth_slider.setValue(int(self.shared_config.smooth_base * 100))
            aimbot_smooth_slider.valueChanged.connect(lambda v: (
                setattr(self.shared_config, 'smooth_base', v / 100.0),
                aimbot_smooth_label.setText(f"Aimbot Smooth Base: {self.shared_config.smooth_base:.2f}")
            ))
            aimbot_layout.addWidget(aimbot_smooth_label)
            aimbot_layout.addWidget(aimbot_smooth_slider)

            # Smooth Var Slider
            aimbot_smooth_var_label = QLabel(f"Aimbot Smooth Var: {self.shared_config.smooth_var:.2f}")
            aimbot_smooth_var_slider = NoWheelSlider(Qt.Horizontal)
            aimbot_smooth_var_slider.setMinimum(0)
            aimbot_smooth_var_slider.setMaximum(50)
            aimbot_smooth_var_slider.setValue(int(self.shared_config.smooth_var * 100))
            aimbot_smooth_var_slider.valueChanged.connect(lambda v: (
                setattr(self.shared_config, 'smooth_var', v / 100.0),
                aimbot_smooth_var_label.setText(f"Aimbot Smooth Var: {self.shared_config.smooth_var:.2f}")
            ))
            aimbot_layout.addWidget(aimbot_smooth_var_label)
            aimbot_layout.addWidget(aimbot_smooth_var_slider)

            # RCS Smooth Base Slider
            rcs_smooth_base_label = QLabel(f"RCS Smooth Base: {self.shared_config.rcs_smooth_base:.2f}")
            rcs_smooth_base_slider = NoWheelSlider(Qt.Horizontal)
            rcs_smooth_base_slider.setMinimum(1)
            rcs_smooth_base_slider.setMaximum(100)
            rcs_smooth_base_slider.setValue(int(self.shared_config.rcs_smooth_base * 100))
            rcs_smooth_base_slider.valueChanged.connect(lambda v: (
                setattr(self.shared_config, 'rcs_smooth_base', v / 100.0),
                rcs_smooth_base_label.setText(f"RCS Smooth Base: {self.shared_config.rcs_smooth_base:.2f}")
            ))
            aimbot_layout.addWidget(rcs_smooth_base_label)
            aimbot_layout.addWidget(rcs_smooth_base_slider)

            # RCS Smooth Var Slider
            rcs_smooth_var_label = QLabel(f"RCS Smooth Var: {self.shared_config.rcs_smooth_var:.2f}")
            rcs_smooth_var_slider = NoWheelSlider(Qt.Horizontal)
            rcs_smooth_var_slider.setMinimum(0)
            rcs_smooth_var_slider.setMaximum(50)
            rcs_smooth_var_slider.setValue(int(self.shared_config.rcs_smooth_var * 100))
            rcs_smooth_var_slider.valueChanged.connect(lambda v: (
                setattr(self.shared_config, 'rcs_smooth_var', v / 100.0),
                rcs_smooth_var_label.setText(f"RCS Smooth Var: {self.shared_config.rcs_smooth_var:.2f}")
            ))
            aimbot_layout.addWidget(rcs_smooth_var_label)
            aimbot_layout.addWidget(rcs_smooth_var_slider)

            # RCS Scale Slider
            rcs_scale_label = QLabel(f"RCS Scale: {self.shared_config.rcs_scale:.2f}")
            rcs_scale_slider = NoWheelSlider(Qt.Horizontal)
            rcs_scale_slider.setMinimum(10)
            rcs_scale_slider.setMaximum(50)
            rcs_scale_slider.setValue(int(self.shared_config.rcs_scale * 10))
            rcs_scale_slider.valueChanged.connect(lambda v: (
                setattr(self.shared_config, 'rcs_scale', v / 10.0),
                rcs_scale_label.setText(f"RCS Scale: {self.shared_config.rcs_scale:.2f}")
            ))
            aimbot_layout.addWidget(rcs_scale_label)
            aimbot_layout.addWidget(rcs_scale_slider)

            # Stabilize Shots Slider
            stabilize_shots_label = QLabel(f"Stabilize Shots: {self.shared_config.stabilize_shots}")
            stabilize_shots_slider = NoWheelSlider(Qt.Horizontal)
            stabilize_shots_slider.setMinimum(1)
            stabilize_shots_slider.setMaximum(10)
            stabilize_shots_slider.setValue(self.shared_config.stabilize_shots)
            stabilize_shots_slider.valueChanged.connect(lambda v: (
                setattr(self.shared_config, 'stabilize_shots', v),
                stabilize_shots_label.setText(f"Stabilize Shots: {v}")
            ))
            aimbot_layout.addWidget(stabilize_shots_label)
            aimbot_layout.addWidget(stabilize_shots_slider)

            # Target Switch Delay Slider
            target_switch_label = QLabel(f"Target Switch Delay: {self.shared_config.target_switch_delay:.2f}s")
            target_switch_slider = NoWheelSlider(Qt.Horizontal)
            target_switch_slider.setMinimum(0)
            target_switch_slider.setMaximum(200)
            target_switch_slider.setValue(int(self.shared_config.target_switch_delay * 100))
            target_switch_slider.valueChanged.connect(lambda v: (
                setattr(self.shared_config, 'target_switch_delay', v / 100.0),
                target_switch_label.setText(f"Target Switch Delay: {self.shared_config.target_switch_delay:.2f}s")
            ))
            aimbot_layout.addWidget(target_switch_label)
            aimbot_layout.addWidget(target_switch_slider)

            # Aim Start Delay Slider
            aim_start_delay_label = QLabel(f"Aim Start Delay: {self.shared_config.aim_start_delay:.2f}s")
            aim_start_delay_slider = NoWheelSlider(Qt.Horizontal)
            aim_start_delay_slider.setMinimum(0)
            aim_start_delay_slider.setMaximum(100)
            aim_start_delay_slider.setValue(int(self.shared_config.aim_start_delay * 100))
            aim_start_delay_slider.valueChanged.connect(lambda v: (
                setattr(self.shared_config, 'aim_start_delay', v / 100.0),
                aim_start_delay_label.setText(f"Aim Start Delay: {self.shared_config.aim_start_delay:.2f}s")
            ))
            aimbot_layout.addWidget(aim_start_delay_label)
            aimbot_layout.addWidget(aim_start_delay_slider)

            # Downward Offset Slider
            downward_offset_label = QLabel(f"Downward Offset: {self.shared_config.downward_offset}")
            downward_offset_slider = NoWheelSlider(Qt.Horizontal)
            downward_offset_slider.setMinimum(0)
            downward_offset_slider.setMaximum(200)
            downward_offset_slider.setValue(self.shared_config.downward_offset)
            downward_offset_slider.valueChanged.connect(lambda v: (
                setattr(self.shared_config, 'downward_offset', v),
                downward_offset_label.setText(f"Downward Offset: {v}")
            ))
            aimbot_layout.addWidget(downward_offset_label)
            aimbot_layout.addWidget(downward_offset_slider)

            target_bone_label = QLabel("Target Bone:")
            target_bone_combo = QComboBox()
            bones = ["head", "chest"]

            target_bone_combo.addItems(bones)

            if hasattr(self.shared_config, "target_bone_name") and self.shared_config.target_bone_name in bones:
                target_bone_combo.setCurrentIndex(bones.index(self.shared_config.target_bone_name))
            else:
                self.shared_config.target_bone_name = "head"
                target_bone_combo.setCurrentIndex(0)

            def on_target_bone_change(index):
                bone = bones[index]
                self.shared_config.target_bone_name = bone
                self.shared_config.target_bone_index = 6 if bone == "head" else 18
                print(f"[GUI] Target Bone changed to: {bone}")



            target_bone_combo.currentIndexChanged.connect(on_target_bone_change)

            aimbot_layout.addWidget(target_bone_label)
            aimbot_layout.addWidget(target_bone_combo)

            aimbot_group.setLayout(aimbot_layout)
            return aimbot_group

        main_layout.addLayout(create_top_row())

        quit_button = QPushButton("Quit GHax")
        quit_button.setStyleSheet("background-color: #FF5555; font-weight: bold;")
        quit_button.clicked.connect(self.quit_ghax)
        main_layout.addWidget(quit_button)

        esp_group = create_esp_group()
        trigger_group = create_triggerbot_group()
        crosshair_group = create_crosshair_group()
        color_group = create_color_group()
        misc_group = create_misc_group()
        aimbot_group = create_aimbot_group()

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        container = QWidget()
        container_layout = QVBoxLayout()

        for group in (aimbot_group, trigger_group, misc_group, esp_group, crosshair_group, color_group):
            container_layout.addWidget(group)

        container.setLayout(container_layout)
        scroll.setWidget(container)
        main_layout.addWidget(scroll)

        self.window.setLayout(main_layout)
        self.window.show()




    def quit_ghax(self):
        if self.fov_overlay:
            self.fov_overlay.close()
        self.window.close()
        sys.exit(0)


    def on_bhop_toggle(self, state):
        self.shared_config.bhop_enabled = (state == Qt.Checked)

    def toggle_distance_esp(self, state):
        self.wall.ToggleDistanceESP(state == Qt.Checked)

    def toggle_shoot_teammates(self, state):
        self.trigger_team = state == Qt.Checked

    def toggle_box_esp(self, state):
        self.wall.ToggleBoxESP(state == Qt.Checked)

    def toggle_healthbar(self, state):
        self.wall.ToggleHealthBar(state == Qt.Checked)

    def toggle_health_esp(self, state):
        self.wall.ToggleHealthESP(state == Qt.Checked)

    def toggle_enemy_only(self, state):
        self.wall.ToggleEnemyOnly(state == Qt.Checked)

    def toggle_team_only(self, state):
        self.wall.ToggleTeamOnly(state == Qt.Checked)

    def toggle_name_esp(self, state):
        self.wall.ToggleNameESP(state == Qt.Checked)

    def toggle_line_esp(self, state):
        self.wall.ToggleLineESP(state == Qt.Checked)

    def toggle_head_esp(self, state):
        self.wall.ToggleHeadESP(state == Qt.Checked)

    def toggle_bone_esp(self):
        state = self.wall.bone_esp_enabled
        self.wall.ToggleBoneESP(not state)

    def toggle_skeleton_esp(self, state):
        self.wall.ToggleSkeletonESP(state == Qt.Checked)

    def toggle_watermark(self, state):
        self.wall.ToggleWatermark(state == Qt.Checked)


    def toggle_crosshair(self, state):
        self.wall.ToggleCrosshair(state == Qt.Checked)

    def change_crosshair_color(self):
        self.wall.ChangeCrosshairColor()

    def toggle_triggerbot(self, state):
        if state == Qt.Checked:
            if not self.trigger_key:  
                self.set_trigger_key()
                if not self.trigger_key: 
                    return
            self.triggerbot = TriggerBot(
                triggerKey=self.trigger_key,
                shootTeammates=self.trigger_team,
                shared_config=self.shared_config
            )
        else:
            self.triggerbot = None

    def toggle_shoot_teammates(self, state):
        self.trigger_team = state == Qt.Checked
        if self.triggerbot:
            self.triggerbot.shootTeammates = self.trigger_team
            
    def set_trigger_key(self):
        dialog = SetTriggerKeyDialog(self.window)
        if dialog.exec_():
            pressed_key = keyboard.read_event(suppress=True)
            self.trigger_key = pressed_key.name
            print(f"Trigger key set to: {self.trigger_key}")

            if self.triggerbot:
                self.triggerbot.triggerKey = self.trigger_key


    def Run(self):
        pw_module.overlay_init(target=self.window.windowTitle(), title=self.window.windowTitle(), fps=self.fps)

        while pw_module.overlay_loop():
            try:
                if self.wall.enabled:
                    self.wall.Render()
                if self.triggerbot:  
                    self.triggerbot.enable()
            except:
                pass
            QApplication.processEvents()


if __name__ == "__main__":
    main()



