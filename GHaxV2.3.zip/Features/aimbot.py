import pymem, pymem.process, time, math, random, winsound
from pynput import mouse, keyboard
from Process.offsets import Offsets
from Process.process_handler import CS2Process

class AimbotRCS:
    def __init__(self, cfg):
        self.cfg, self.pm = cfg, pymem.Pymem("cs2.exe")
        self.o, self.cs2 = Offsets(), CS2Process(); self.cs2.initialize()
        self.base = self.cs2.module_base
        self.bone_indices = {"head": 6, "chest": 18}
        self.left_down, self.shots_fired = False, 0
        self.last_punch, self.target_id = (0.0, 0.0), None
        self.last_target_lost_time, self.aim_start_time = 0, None

        mouse.Listener(on_click=self.on_click, daemon=True).start()
        keyboard.Listener(on_press=self.on_key, daemon=True).start()

    def get_current_bone_index(self):
        return self.bone_indices.get(self.cfg.target_bone_name, 6)

    def read(self, addr, t="int"):
        if not addr: return 0.0 if t == "float" else 0
        try: return {"int": self.pm.read_int, "long": self.pm.read_longlong, "float": self.pm.read_float, "ushort": self.pm.read_ushort}[t](addr)
        except: return 0.0 if t == "float" else 0

    def get_entity(self, base, idx):
        offset1 = 8 * ((idx & 0x7FFF) >> 9) + 16
        entry = self.read(base + offset1, "long")
        if not entry: return 0
        offset2 = 0x78 * (idx & 0x1FF)
        ctrl = self.read(entry + offset2, "long")
        return ctrl if ctrl and ctrl != self.read(self.base + self.o.dwLocalPlayerController, "long") else 0

    def read_vec3(self, addr):
        return [self.read(addr + i * 4, "float") for i in range(3)]

    def read_weapon_id(self, pawn):
        w = self.read(pawn + self.o.m_pClippingWeapon, "long")
        return self.read(w + self.o.m_AttributeManager + self.o.m_Item + self.o.m_iItemDefinitionIndex, "ushort") if w else None

    def read_bone_pos(self, pawn, idx):
        scene = self.read(pawn + self.o.m_pGameSceneNode, "long")
        bones = self.read(scene + self.o.m_pBoneArray, "long") if scene else 0
        return self.read_vec3(bones + idx * 32) if bones else None

    def calc_angle(self, src, dst):
        delta = [dst[i] - src[i] for i in range(3)]
        hyp = math.hypot(delta[0], delta[1])
        return -math.degrees(math.atan2(delta[2], hyp)), math.degrees(math.atan2(delta[1], delta[0]))

    def normalize(self, pitch, yaw):
        if math.isnan(pitch) or math.isnan(yaw): return 0.0, 0.0
        pitch = max(min(pitch, 89.0), -89.0)
        yaw = ((yaw + 180) % 360) - 180
        return pitch, yaw

    def angle_diff(self, a, b):
        diff = a - b
        while diff < -180: diff += 360
        while diff > 180: diff -= 360
        return diff

    def in_fov(self, p1, y1, p2, y2):
        diff_pitch = self.angle_diff(p2, p1)
        diff_yaw = self.angle_diff(y2, y1)
        return math.hypot(diff_pitch, diff_yaw) <= self.cfg.FOV

    def lerp(self, a, b, t): return a + (b - a) * t
    def add_noise(self, val, max_n=0.03): return val + random.uniform(-max_n, max_n)

    def on_click(self, x, y, btn, pressed):
        if btn == mouse.Button.left:
            self.left_down = pressed
            self.aim_start_time = time.time() if pressed else None
            if not pressed:
                self.shots_fired = 0
                self.last_punch = (0.0, 0.0)

    def on_key(self, key):
        try:
            if key.char == '[':
                self.cfg.enabled ^= True
                winsound.Beep(760 if self.cfg.enabled else 430, 130)
                print(f"[+] Aimbot {'ENABLED' if self.cfg.enabled else 'DISABLED'}")
            elif key.char == ']':
                new_bone = "chest" if self.cfg.target_bone_name == "head" else "head"
                self.cfg.target_bone_name = new_bone
                winsound.Beep(880 if new_bone == "chest" else 660, 150)
                print(f"[+] Target bone: {new_bone.upper()}")
            elif key.char == '\\':
                self.cfg.DeathMatch ^= True
                winsound.Beep(700 if self.cfg.DeathMatch else 500, 200)
                print(f"[+] DeathMatch: {'ENABLED' if self.cfg.DeathMatch else 'DISABLED'}")
        except: pass

    def run(self):
        while not self.cfg.stop:
            try:
                if not self.cfg.enabled: time.sleep(0.01); continue

                pawn = self.read(self.base + self.o.dwLocalPlayerPawn, "long")
                if not pawn or self.read(pawn + self.o.m_iHealth) <= 0: time.sleep(0.01); continue

                ctrl = self.read(self.base + self.o.dwLocalPlayerController, "long")
                weapon_id = self.read_weapon_id(pawn)
                if weapon_id in {42, 43, 44, 45, 47, 48}: self.shots_fired = 0; self.last_punch = (0.0, 0.0); time.sleep(0.01); continue

                my_team = self.read(pawn + self.o.m_iTeamNum)
                my_pos = self.read_vec3(pawn + self.o.m_vOldOrigin)
                pitch = self.read(self.base + self.o.dwViewAngles, "float")
                yaw = self.read(self.base + self.o.dwViewAngles + 4, "float")
                recoil = (
                    self.read(pawn + self.o.m_aimPunchAngle, "float"),
                    self.read(pawn + self.o.m_aimPunchAngle + 4, "float")
                )
                entity_list = self.read(self.base + self.o.dwEntityList, "long")
                if not entity_list: time.sleep(0.01); continue

                target, target_pos = None, None
                bone_index = self.get_current_bone_index()

                if self.target_id is not None:
                    t_ctrl = self.get_entity(entity_list, self.target_id)
                    t_pawn = self.get_entity(entity_list, self.read(t_ctrl + self.o.m_hPlayerPawn) & 0x7FFF) if t_ctrl else 0
                    if t_pawn and self.read(t_pawn + self.o.m_iHealth) > 0 and (self.cfg.DeathMatch or self.read(t_pawn + self.o.m_iTeamNum) != my_team):
                        pos = self.read_bone_pos(t_pawn, bone_index) or self.read_vec3(t_pawn + self.o.m_vOldOrigin)
                        pos[2] -= self.cfg.downward_offset
                        tp, ty = self.calc_angle(my_pos, pos)
                        if not math.isnan(tp) and not math.isnan(ty) and self.in_fov(pitch, yaw, tp, ty):
                            target, target_pos = t_pawn, pos
                        else:
                            self.target_id = None
                            self.last_target_lost_time = time.time()
                    else:
                        self.target_id = None
                        self.last_target_lost_time = time.time()
                else:
                    if self.last_target_lost_time and time.time() - self.last_target_lost_time < self.cfg.target_switch_delay:
                        time.sleep(0.01); continue

                    for i in range(self.cfg.max_entities):
                        ctrl_ent = self.get_entity(entity_list, i)
                        if not ctrl_ent or ctrl_ent == ctrl: continue
                        pawn_ent = self.get_entity(entity_list, self.read(ctrl_ent + self.o.m_hPlayerPawn) & 0x7FFF)
                        if not pawn_ent or self.read(pawn_ent + self.o.m_iHealth) <= 0: continue
                        if not self.cfg.DeathMatch and self.read(pawn_ent + self.o.m_iTeamNum) == my_team: continue
                        pos = self.read_bone_pos(pawn_ent, bone_index) or self.read_vec3(pawn_ent + self.o.m_vOldOrigin)
                        pos[2] -= self.cfg.downward_offset
                        tp, ty = self.calc_angle(my_pos, pos)
                        if math.isnan(tp) or math.isnan(ty): continue
                        if not self.in_fov(pitch, yaw, tp, ty): continue
                        if not target or math.dist(my_pos, pos) < math.dist(my_pos, target_pos):
                            target, target_pos, self.target_id = pawn_ent, pos, i

                if self.left_down:
                    if self.aim_start_time and time.time() - self.aim_start_time < self.cfg.aim_start_delay: continue
                    self.shots_fired += 1

                    if target and target_pos:
                        tp, ty = self.calc_angle(my_pos, target_pos)
                        if abs(self.angle_diff(ty, yaw)) > 90: continue

                        cp = tp - recoil[0] * self.cfg.rcs_scale
                        cy = ty - recoil[1] * self.cfg.rcs_scale
                        smooth = max(0.05, min(self.cfg.smooth_base + random.uniform(-self.cfg.smooth_var, self.cfg.smooth_var), 0.3))
                        sp = self.add_noise(pitch + self.angle_diff(cp, pitch) * smooth, 0.05)
                        sy = self.add_noise(yaw + self.angle_diff(cy, yaw) * smooth, 0.05)
                        sp, sy = self.normalize(sp, sy)

                        self.pm.write_float(self.base + self.o.dwViewAngles, sp)
                        self.pm.write_float(self.base + self.o.dwViewAngles + 4, sy)

                    elif self.shots_fired >= self.cfg.stabilize_shots:
                        dp, dy = (recoil[0] - self.last_punch[0]) * self.cfg.rcs_scale, (recoil[1] - self.last_punch[1]) * self.cfg.rcs_scale
                        sp, sy = self.normalize(pitch - dp, yaw - dy)
                        rcs_smooth = max(0.07, min(self.cfg.rcs_smooth_base + random.uniform(-self.cfg.rcs_smooth_var, self.cfg.rcs_smooth_var), 0.35))
                        sp = self.add_noise(self.lerp(pitch, sp, rcs_smooth))
                        sy = self.add_noise(self.lerp(yaw, sy, rcs_smooth))

                        self.pm.write_float(self.base + self.o.dwViewAngles, sp)
                        self.pm.write_float(self.base + self.o.dwViewAngles + 4, sy)

                    self.last_punch = recoil
                else:
                    self.shots_fired, self.last_punch, self.aim_start_time = 0, (0.0, 0.0), None

                time.sleep(0.007 + random.uniform(0, 0.006))

            except (EOFError, BrokenPipeError):
                break
            except Exception as e:
                print(f"[!] Exception in AimbotRCS: {e}")
                time.sleep(0.5)

        print("[AimbotRCS] Stopped.")

def start_aim_rcs(shared_config):
    print("[*] Starting AimRCS...")
    AimbotRCS(shared_config).run()
