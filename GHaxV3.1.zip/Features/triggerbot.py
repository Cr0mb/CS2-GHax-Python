import time
import random
import keyboard
import pymem
import pymem.process
from pynput.mouse import Controller, Button
from win32gui import GetWindowText, GetForegroundWindow
import winsound
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel
from PyQt5.QtCore import Qt
from Process.offsets import Offsets
from Process.process_handler import CS2Process


class TriggerBot:
    def __init__(self, triggerKey="shift", shootTeammates=False, shared_config=None):
        self.triggerKey = triggerKey
        self.shootTeammates = shootTeammates

        self.cs2 = CS2Process()
        self.cs2.initialize()

        self.pm = pymem.Pymem("cs2.exe")
        self.client = self.cs2.module_base

        self.offsets_manager = Offsets()
        self.mouse = Controller()
        self.last_shot_time = 0

        # Shared configuration object from GUI
        if shared_config:
            self.shared_config = shared_config
        else:
            class DummyConfig:
                stop = False
                triggerbot_cooldown = 0.8
                triggerbot_enabled = True
                shoot_teammates = False
            self.shared_config = DummyConfig()

    def shoot(self):
        self.mouse.press(Button.left)
        time.sleep(0.005)  # very short tap
        self.mouse.release(Button.left)

    def enable(self):
        try:
            if GetWindowText(GetForegroundWindow()) != "Counter-Strike 2":
                return

            always_on = getattr(self.shared_config, "triggerbot_always_on", False)

            # Only check triggerKey if always_on is False
            if not always_on and not keyboard.is_pressed(self.triggerKey):
                return

            player = self.pm.read_longlong(self.client + self.offsets_manager.dwLocalPlayerPawn)
            entityId = self.pm.read_int(player + self.offsets_manager.m_iIDEntIndex)

            if entityId <= 0:
                return

            entList = self.pm.read_longlong(self.client + self.offsets_manager.dwEntityList)
            entEntry = self.pm.read_longlong(entList + 0x8 * (entityId >> 9) + 0x10)
            entity = self.pm.read_longlong(entEntry + 120 * (entityId & 0x1FF))

            entityTeam = self.pm.read_int(entity + self.offsets_manager.m_iTeamNum)
            entityHp = self.pm.read_int(entity + self.offsets_manager.m_iHealth)
            playerTeam = self.pm.read_int(player + self.offsets_manager.m_iTeamNum)

            cooldown = getattr(self.shared_config, "triggerbot_cooldown", 0.8)
            allow_team = getattr(self.shared_config, "shoot_teammates", False)

            if entityTeam != 0 and entityHp > 0:
                if allow_team or (entityTeam != playerTeam):
                    current_time = time.time()
                    if current_time - self.last_shot_time >= cooldown:
                        self.shoot()
                        self.last_shot_time = current_time

        except KeyboardInterrupt:
            pass
        except Exception as e:
            print(f"[TriggerBot] Exception: {e}")

    def toggle_shoot_teammates(self, state):
        self.shootTeammates = state == Qt.Checked
        self.shared_config.shoot_teammates = self.shootTeammates

    def run(self):
        print("[*] TriggerBot started.")
        try:
            while not getattr(self.shared_config, "stop", False):
                if getattr(self.shared_config, "triggerbot_enabled", True):
                    self.enable()
                time.sleep(0.005)  # Fast polling
        except KeyboardInterrupt:
            print("[*] TriggerBot interrupted by user.")
        finally:
            print("[TriggerBot] Stopped.")


class SetTriggerKeyDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Set Trigger Key")
        self.setModal(True)
        self.trigger_key = None

        layout = QVBoxLayout()
        label = QLabel("Press the key you want to use as the trigger key...")
        layout.addWidget(label)
        self.setLayout(layout)

    def keyPressEvent(self, event):
        self.trigger_key = event.text().lower()
        self.accept()
        winsound.Beep(1000, 200)


# Standalone test run
if __name__ == "__main__":
    class DummySharedConfig:
        stop = False
        triggerbot_enabled = True
        shoot_teammates = False
        triggerbot_cooldown = 0.2

    bot = TriggerBot(triggerKey="shift", shared_config=DummySharedConfig())
    bot.run()
