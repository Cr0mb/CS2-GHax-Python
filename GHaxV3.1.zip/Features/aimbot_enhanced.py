import pymem, time, math, random, json, threading
from pynput import mouse
from Process.offsets import Offsets
from Process.process_handler import CS2Process
import requests
from requests import get
import ctypes
import time
import pyMeow as pw_module
from ctypes import windll




# === SendInput setup for external mouse movement ===
INPUT_MOUSE = 0
MOUSEEVENTF_MOVE = 0x0001

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", ctypes.c_long),
                ("dy", ctypes.c_long),
                ("mouseData", ctypes.c_ulong),
                ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong),
                ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong))]

class INPUT(ctypes.Structure):
    class _INPUT(ctypes.Union):
        _fields_ = [("mi", MOUSEINPUT)]
    _fields_ = [("type", ctypes.c_ulong), ("ii", _INPUT)]

SendInput = ctypes.windll.user32.SendInput

def move_mouse(dx, dy):
    mi = MOUSEINPUT(dx=dx, dy=dy, mouseData=0, dwFlags=MOUSEEVENTF_MOVE, time=0, dwExtraInfo=None)
    inp = INPUT(type=INPUT_MOUSE, ii=INPUT._INPUT(mi=mi))
    SendInput(1, ctypes.byref(inp), ctypes.sizeof(inp))

def is_alt_held():
    VK_MENU = 0x12  # Virtual-Key code for the ALT key
    return windll.user32.GetAsyncKeyState(VK_MENU) & 0x8000 != 0


class CS2WeaponTracker:
    VALID_WEAPON_IDS = {
        41, 42, 59, 80, 500, 505, 506, 507, 508, 509, 512, 514, 515, 516, 519, 520, 522, 523,
        44, 43, 45, 46, 47, 48, 49
    }

    def __init__(self):
        self.pm = None
        self.client = None
        self.attach_to_process()

    def attach_to_process(self):
        while True:
            try:
                self.pm = pymem.Pymem("cs2.exe")
                self.client = pymem.process.module_from_name(self.pm.process_handle, "client.dll").lpBaseOfDll
                break
            except Exception as e:
                time.sleep(1)

    def get_current_weapon_id(self):
        try:
            local_player = self.pm.read_longlong(self.client + Offsets.dwLocalPlayerPawn)
            if not local_player:
                return None

            weapon_ptr = self.pm.read_longlong(local_player + Offsets.m_pClippingWeapon)
            if not weapon_ptr:
                return None

            weapon_id = self.pm.read_int(
                weapon_ptr + Offsets.m_AttributeManager + Offsets.m_Item + Offsets.m_iItemDefinitionIndex
            )
            return weapon_id
        except Exception as e:
            return None

    def is_weapon_valid_for_aim(self):
        weapon_id = self.get_current_weapon_id()
        if weapon_id is None:
            return True
        valid = weapon_id not in self.VALID_WEAPON_IDS
        return valid


class AimbotRCS:
    MAX_DELTA_ANGLE = 60
    LEARN_FILE = "aimbot.json"
    
    # Sensitivity tweak for converting angles to mouse movement
    SENSITIVITY = 0.022
    INVERT_Y = -1

    def __init__(self, cfg):
        self.cfg, self.pm = cfg, pymem.Pymem("cs2.exe")
        self.o, self.cs2 = Offsets(), CS2Process()
        self.cs2.initialize()
        self.base = self.cs2.module_base
        self.bone_indices = {"head":6, "chest":18}
        self.left_down = False
        self.shots_fired = 0
        self.last_punch = (0.0, 0.0)
        self.target_id = None
        self.last_target_lost_time = 0
        self.aim_start_time = None
        self.last_aim_angle = None
        self.lock = threading.Lock()
        self.load_learning()
        self.learning_dirty = False
        mouse.Listener(on_click=self.on_click, daemon=True).start()
        threading.Thread(target=self.periodic_save, daemon=True).start()

        # Initialize weapon tracker instance
        self.weapon_tracker = CS2WeaponTracker()

    def periodic_save(self):
        while not self.cfg.stop:
            time.sleep(30)
            if self.cfg.enable_learning and self.learning_dirty:
                self.save_learning()
                self.learning_dirty = False

    def load_learning(self):
        try:
            with open(self.LEARN_FILE) as f:
                self.learning_data = {k:[tuple(x) for x in v] for k,v in json.load(f).items()}
        except:
            self.learning_data = {}

    def save_learning(self):
        try:
            with self.lock, open(self.LEARN_FILE, "w") as f:
                json.dump({k:[list(x) for x in v] for k,v in self.learning_data.items()}, f)
        except Exception as e:
            print(f"[!] Failed saving: {e}")

    def read(self, addr, t="int"):
        if not addr: return 0.0 if t=="float" else 0
        try: return {"int":self.pm.read_int,"long":self.pm.read_longlong,"float":self.pm.read_float,"ushort":self.pm.read_ushort}[t](addr)
        except: return 0.0 if t=="float" else 0

    def get_entity(self, base, idx):
        e = self.read(base + 8*((idx & 0x7FFF)>>9) + 16, "long")
        if not e: return 0
        ctrl = self.read(e + 0x78*(idx & 0x1FF), "long")
        local_ctrl = self.read(self.base + self.o.dwLocalPlayerController, "long")
        return ctrl if ctrl and ctrl != local_ctrl else 0

    def read_vec3(self, addr): return [self.read(addr + i*4, "float") for i in range(3)]

    def read_weapon_id(self, pawn):
        w = self.read(pawn + self.o.m_pClippingWeapon, "long")
        return self.read(w + self.o.m_AttributeManager + self.o.m_Item + self.o.m_iItemDefinitionIndex, "ushort") if w else 0

    def read_bone_pos(self, pawn, idx):
        scene = self.read(pawn + self.o.m_pGameSceneNode, "long")
        bones = self.read(scene + self.o.m_pBoneArray, "long") if scene else 0
        return self.read_vec3(bones + idx*32) if bones else None

    def calc_angle(self, src, dst):
        dx,dy,dz = [dst[i]-src[i] for i in range(3)]
        hyp = math.hypot(dx, dy)
        return -math.degrees(math.atan2(dz, hyp)), math.degrees(math.atan2(dy, dx))

    def normalize(self, p,y):
        if math.isnan(p) or math.isnan(y): return 0.0,0.0
        return max(min(p,89),-89), ((y+180)%360)-180

    def angle_diff(self, a,b):
        d = a-b
        while d<-180: d+=360
        while d>180: d-=360
        return d

    def in_fov(self, p1,y1,p2,y2):
        return math.hypot(self.angle_diff(p2,p1), self.angle_diff(y2,y1)) <= self.cfg.FOV

    lerp = staticmethod(lambda a,b,t: a+(b-a)*t)
    add_noise = staticmethod(lambda v,max_n=0.03: v+random.uniform(-max_n,max_n))

    def clamp_angle_diff(self, current, target, max_delta=MAX_DELTA_ANGLE):
        d = self.angle_diff(target, current)
        if abs(d) > max_delta: d = max_delta if d>0 else -max_delta
        return current + d

    def on_click(self, x,y,btn,pressed):
        if btn==mouse.Button.left:
            self.left_down=pressed
            self.aim_start_time = time.time() if pressed else None
            if not pressed:
                self.shots_fired=0
                self.last_punch=(0.0,0.0)
                self.last_aim_angle=None

    def store_learning(self, key, dp, dy):
        if not self.cfg.enable_learning:
            return
        with self.lock:
            l = self.learning_data.setdefault(key, [])
            l.append((dp, dy))
            if len(l) > 50: l.pop(0)
            self.learning_dirty = True

    def get_learned_correction(self, key):
        if not self.cfg.enable_learning:
            return 0.0, 0.0
        with self.lock:
            d = self.learning_data.get(key)
            if not d: return 0.0,0.0
            return sum(x[0] for x in d)/len(d), sum(x[1] for x in d)/len(d)

    def quantize_angle(self, p, y, step=1.0):
        return f"{round(p/step)*step:.1f}_{round(y/step)*step:.1f}"

    def get_current_bone_index(self, pawn=None, my_pos=None, pitch=None, yaw=None):
        if not self.cfg.closest_to_crosshair:
            return self.bone_indices.get(self.cfg.target_bone_name, 6)

        if not pawn or not my_pos:
            return self.bone_indices.get("head", 6)

        best_index = None
        best_distance = float('inf')

        for idx in self.cfg.bone_indices_to_try:
            pos = self.read_bone_pos(pawn, idx)
            if not pos:
                continue
            if self.cfg.enable_velocity_prediction:
                vel = self.read_vec3(pawn + self.o.m_vecVelocity)
                pos = [pos[i] + vel[i] * 0.1 for i in range(3)]
            pos[2] -= self.cfg.downward_offset
            p, y = self.calc_angle(my_pos, pos)
            if any(math.isnan(a) for a in (p, y)):
                continue
            dist = math.hypot(self.angle_diff(p, pitch), self.angle_diff(y, yaw))
            if dist < best_distance:
                best_distance = dist
                best_index = idx

        return best_index if best_index is not None else self.bone_indices.get("head", 6)


    def run(self):
        def normalize_angle_delta(delta):
            while delta > 180:
                delta -= 360
            while delta < -180:
                delta += 360
            return delta

        def is_valid_target(pawn, my_team):
            return (
                pawn
                and self.read(pawn + self.o.m_iHealth) > 0
                and self.read(pawn + self.o.m_lifeState) == 256  # Must be alive
                and not self.read(pawn + self.o.m_bDormant, "int")
                and (self.cfg.DeathMatch or self.read(pawn + self.o.m_iTeamNum) != my_team)
            )

        while not self.cfg.stop:
            try:
                if not self.cfg.enabled:
                    time.sleep(0.01)
                    continue

                pawn = self.read(self.base + self.o.dwLocalPlayerPawn, "long")
                if not pawn or self.read(pawn + self.o.m_iHealth) <= 0:
                    time.sleep(0.01)
                    continue

                ctrl = self.read(self.base + self.o.dwLocalPlayerController, "long")

                if not self.weapon_tracker.is_weapon_valid_for_aim():
                    self.shots_fired = 0
                    self.last_punch = (0.0, 0.0)
                    time.sleep(0.01)
                    continue

                my_team = self.read(pawn + self.o.m_iTeamNum)
                my_pos = self.read_vec3(pawn + self.o.m_vOldOrigin)
                pitch = self.read(self.base + self.o.dwViewAngles, "float")
                yaw = self.read(self.base + self.o.dwViewAngles + 4, "float")
                recoil = (
                    self.read(pawn + self.o.m_aimPunchAngle, "float"),
                    self.read(pawn + self.o.m_aimPunchAngle + 4, "float")
                )

                entity_list = self.read(self.base + self.o.dwEntityList, "long")
                if not entity_list:
                    time.sleep(0.01)
                    continue

                target = target_pos = None
                bone_index = self.get_current_bone_index(pawn, my_pos, pitch, yaw)

                if self.target_id is not None:
                    t_ctrl = self.get_entity(entity_list, self.target_id)
                    t_pawn = self.get_entity(entity_list, self.read(t_ctrl + self.o.m_hPlayerPawn) & 0x7FFF) if t_ctrl else 0

                    if is_valid_target(t_pawn, my_team):
                        bone_index = self.get_current_bone_index(t_pawn, my_pos, pitch, yaw)
                        pos = self.read_bone_pos(t_pawn, bone_index) or self.read_vec3(t_pawn + self.o.m_vOldOrigin)

                        if self.cfg.enable_velocity_prediction:
                            vel = self.read_vec3(t_pawn + self.o.m_vecVelocity)
                            predicted = [pos[i] + vel[i] * 0.1 for i in range(3)]
                        else:
                            predicted = pos[:]
                        predicted[2] -= self.cfg.downward_offset

                        tp, ty = self.calc_angle(my_pos, predicted)
                        if not any(math.isnan(x) for x in (tp, ty)) and self.in_fov(pitch, yaw, tp, ty):
                            target, target_pos = t_pawn, predicted
                        else:
                            target = None
                            target_pos = None
                            self.target_id = None
                            self.last_target_lost_time = time.time()
                    else:
                        target = None
                        target_pos = None
                        self.target_id = None
                        self.last_target_lost_time = time.time()

                else:
                    if self.last_target_lost_time and time.time() - self.last_target_lost_time < self.cfg.target_switch_delay:
                        time.sleep(0.01)
                        continue

                    for i in range(self.cfg.max_entities):
                        ctrl_ent = self.get_entity(entity_list, i)
                        if not ctrl_ent or ctrl_ent == ctrl:
                            continue
                        pawn_ent = self.get_entity(entity_list, self.read(ctrl_ent + self.o.m_hPlayerPawn) & 0x7FFF)
                        if not is_valid_target(pawn_ent, my_team):
                            continue

                        bone_index = self.get_current_bone_index(pawn_ent, my_pos, pitch, yaw)
                        pos = self.read_bone_pos(pawn_ent, bone_index) or self.read_vec3(pawn_ent + self.o.m_vOldOrigin)

                        if self.cfg.enable_velocity_prediction:
                            vel = self.read_vec3(pawn_ent + self.o.m_vecVelocity)
                            predicted = [pos[i] + vel[i] * 0.1 for i in range(3)]
                        else:
                            predicted = pos[:]
                        predicted[2] -= self.cfg.downward_offset

                        tp, ty = self.calc_angle(my_pos, predicted)
                        if any(math.isnan(x) for x in (tp, ty)) or not self.in_fov(pitch, yaw, tp, ty):
                            continue

                        if not target or math.dist(my_pos, predicted) < math.dist(my_pos, target_pos):
                            target, target_pos, self.target_id = pawn_ent, predicted, i

                if self.left_down or is_alt_held():
                    if self.aim_start_time and time.time() - self.aim_start_time < self.cfg.aim_start_delay:
                        continue

                    self.shots_fired += 1
                    if target and target_pos:
                        tp, ty = self.calc_angle(my_pos, target_pos)
                        if abs(self.angle_diff(ty, yaw)) > 90:
                            continue

                        if self.cfg.rcs_enabled:
                            cp = tp - recoil[0] * self.cfg.rcs_scale
                            cy = ty - recoil[1] * self.cfg.rcs_scale
                        else:
                            cp = tp
                            cy = ty

                        smooth = max(0.05, min(self.cfg.smooth_base + random.uniform(-self.cfg.smooth_var, self.cfg.smooth_var), 0.3))
                        cp = self.clamp_angle_diff(pitch, cp)
                        cy = self.clamp_angle_diff(yaw, cy)

                        key = self.quantize_angle(cp, cy)
                        dp, dy = self.get_learned_correction(key)
                        cp += dp
                        cy += dy

                        sp = self.add_noise(pitch + (cp - pitch) * smooth, 0.05)
                        sy = self.add_noise(yaw + (cy - yaw) * smooth, 0.05)
                        sp, sy = self.normalize(sp, sy)

                        # --- REPLACE MEMORY WRITE WITH EXTERNAL MOUSE MOVE ---
                        delta_pitch = normalize_angle_delta(sp - pitch)
                        delta_yaw = normalize_angle_delta(sy - yaw)

                        mouse_dx = int(self.clamp_angle_diff(0, -delta_yaw) / self.SENSITIVITY)
                        mouse_dy = int(self.clamp_angle_diff(0, -delta_pitch) / self.SENSITIVITY) * self.INVERT_Y


                        move_mouse(mouse_dx, mouse_dy)
                        # ------------------------------------------------------

                        if self.last_aim_angle:
                            lp, ly = self.last_aim_angle
                            if abs(self.angle_diff(sp, lp)) > 0.01 or abs(self.angle_diff(sy, ly)) > 0.01:
                                dp_learn = sp - pitch
                                dy_learn = sy - yaw
                                self.store_learning(key, dp_learn, dy_learn)

                        self.last_aim_angle = (sp, sy)
                    else:
                        self.last_aim_angle = None
                else:
                    self.shots_fired = 0
                    self.last_punch = (0.0, 0.0)
                    self.last_aim_angle = None

                time.sleep(0.007 + random.uniform(0, 0.006))

            except (EOFError, BrokenPipeError):
                break
            except Exception as e:
                print(f"[!] Exception in AimbotRCS: {e}")
                time.sleep(0.5)

        if self.cfg.enable_learning:
            self.save_learning()

        print("[AimbotRCS] Stopped.")


def start_aim_rcs(cfg):
    print("[*] Starting AimRCS...")
    AimbotRCS(cfg).run()
