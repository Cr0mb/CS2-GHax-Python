import pymem
import pymem.process
import time
import math
import random
from pynput import mouse, keyboard
import winsound

from offsets import Offsets

class AimbotRCS:
    def __init__(self):
        self.pm = pymem.Pymem("cs2.exe")
        self.base = pymem.process.module_from_name(self.pm.process_handle, "client.dll").lpBaseOfDll
        self.o = Offsets()

        # Config
        self.FOV = 7.5
        self.smooth_base = 0.14
        self.smooth_var = 0.05
        self.rcs_smooth_base = 0.18
        self.rcs_smooth_var = 0.06
        self.rcs_scale = 2.4
        self.stabilize_shots = 2
        self.max_entities = 64
        self.target_switch_delay = 1.0
        self.aim_start_delay = 0.07
        self.downward_offset = 60

        self.bone_indices = {"head": 6, "chest": 18}
        self.target_bone_name = "head"
        self.target_bone_index = self.bone_indices[self.target_bone_name]

        self.DeathMatch = True

        # State
        self.enabled = False
        self.left_down = False
        self.shots_fired = 0
        self.last_punch = (0.0, 0.0)
        self.target_id = None
        self.last_target_lost_time = 0
        self.aim_start_time = None
        self.running = False

        mouse.Listener(on_click=self.on_click).start()
        keyboard.Listener(on_press=self.on_key).start()

    # Unified safe read with default values
    def safe_read(self, addr, type_="int"):
        if not addr:
            return 0 if type_ != "float" else 0.0
        try:
            if type_ == "int":
                return self.pm.read_int(addr)
            elif type_ == "long":
                return self.pm.read_longlong(addr)
            elif type_ == "float":
                return self.pm.read_float(addr)
            elif type_ == "ushort":
                return self.pm.read_ushort(addr)
        except Exception:
            return 0 if type_ != "float" else 0.0

    def get_entity(self, base, idx):
        entry = self.safe_read(base + 0x8 * (idx >> 9) + 0x10, "long")
        if not entry:
            return 0
        entity = self.safe_read(entry + 120 * (idx & 0x1FF), "long")
        return entity or 0

    def read_vec3(self, addr):
        return [self.safe_read(addr + i*4, "float") for i in range(3)]

    def read_weapon_id(self, pawn):
        weapon_ptr = self.safe_read(pawn + self.o.m_pClippingWeapon, "long")
        if not weapon_ptr:
            return None
        weapon_id_addr = weapon_ptr + self.o.m_AttributeManager + self.o.m_Item + self.o.m_iItemDefinitionIndex
        return self.safe_read(weapon_id_addr, "ushort")

    def read_bone_pos(self, pawn, bone_idx):
        game_scene = self.safe_read(pawn + self.o.m_pGameSceneNode, "long")
        if not game_scene:
            return None
        bone_array = self.safe_read(game_scene + self.o.m_pBoneArray, "long")
        if not bone_array:
            return None
        return self.read_vec3(bone_array + bone_idx * 32)

    def calc_angle(self, src, dst):
        delta = [dst[i] - src[i] for i in range(3)]
        hyp = math.hypot(delta[0], delta[1])
        pitch = -math.degrees(math.atan2(delta[2], hyp))
        yaw = math.degrees(math.atan2(delta[1], delta[0]))
        return pitch, yaw

    def normalize(self, pitch, yaw):
        pitch = max(min(pitch, 89.0), -89.0)
        yaw = (yaw + 180) % 360 - 180
        return pitch, yaw

    def angle_diff(self, a1, a2):
        diff = (a1 - a2) % 360
        return diff - 360 if diff > 180 else diff

    def in_fov(self, p1, y1, p2, y2):
        return math.hypot(self.angle_diff(p2, p1), self.angle_diff(y2, y1)) <= self.FOV

    def lerp(self, start, end, t):
        return start + (end - start) * t

    def add_noise(self, angle, max_noise=0.07):
        return angle + random.uniform(-max_noise, max_noise)

    def on_click(self, x, y, button, pressed):
        if button == mouse.Button.left:
            self.left_down = pressed
            self.aim_start_time = time.time() if pressed else None
            if not pressed:
                self.shots_fired = 0
                self.last_punch = (0.0, 0.0)

    def on_key(self, key):
        try:
            if key.char == '[':
                self.enabled = not self.enabled
                winsound.Beep(760 if self.enabled else 430, 130 if self.enabled else 280)
                print(f"[+] Aimbot {'ENABLED' if self.enabled else 'DISABLED'}")
            elif key.char == ']':
                if self.target_bone_name == "head":
                    self.target_bone_name = "chest"
                    self.target_bone_index = self.bone_indices["chest"]
                    winsound.Beep(880, 150)
                else:
                    self.target_bone_name = "head"
                    self.target_bone_index = self.bone_indices["head"]
                    winsound.Beep(660, 150)
                print(f"[+] Target bone changed to: {self.target_bone_name.upper()}")
            elif key.char == '\\':
                self.DeathMatch = not self.DeathMatch
                winsound.Beep(700 if self.DeathMatch else 500, 200)
                print(f"[+] DeathMatch {'ENABLED' if self.DeathMatch else 'DISABLED'} - will {'shoot teammates and enemies' if self.DeathMatch else 'shoot only enemies'}")
        except AttributeError:
            pass

    def run(self):
        self.running = True
        while True:
            try:
                if not self.enabled:
                    time.sleep(0.15)
                    continue

                pawn = self.safe_read(self.base + self.o.dwLocalPlayerPawn, "long")
                if not pawn:
                    time.sleep(0.1)
                    continue

                if self.safe_read(pawn + self.o.m_iHealth) <= 0:
                    time.sleep(0.1)
                    continue

                ctrl = self.safe_read(self.base + self.o.dwLocalPlayerController, "long")
                if not ctrl:
                    time.sleep(0.1)
                    continue

                weapon_id = self.read_weapon_id(pawn)
                if weapon_id == 42:  # Knife or no weapon
                    self.shots_fired = 0
                    self.last_punch = (0.0, 0.0)
                    self.aim_start_time = None
                    time.sleep(0.07)
                    continue

                my_team = self.safe_read(pawn + self.o.m_iTeamNum)
                my_pos = self.read_vec3(pawn + self.o.m_vOldOrigin)

                pitch = self.safe_read(self.base + self.o.dwViewAngles, "float")
                yaw = self.safe_read(self.base + self.o.dwViewAngles + 4, "float")

                recoil = (
                    self.safe_read(pawn + self.o.m_aimPunchAngle, "float"),
                    self.safe_read(pawn + self.o.m_aimPunchAngle + 4, "float")
                )

                entity_list = self.safe_read(self.base + self.o.dwEntityList, "long")
                if not entity_list:
                    time.sleep(0.1)
                    continue

                target = None
                target_pos = None
                min_dist = float("inf")

                # Validate current target
                if self.target_id is not None:
                    t_ctrl = self.get_entity(entity_list, self.target_id)
                    if t_ctrl:
                        t_pawn_id = self.safe_read(t_ctrl + self.o.m_hPlayerPawn) & 0x7FFF
                        t_pawn = self.get_entity(entity_list, t_pawn_id)
                        if t_pawn:
                            hp = self.safe_read(t_pawn + self.o.m_iHealth)
                            team = self.safe_read(t_pawn + self.o.m_iTeamNum)
                            if hp > 0 and (self.DeathMatch or team != my_team):
                                bone_pos = self.read_bone_pos(t_pawn, self.target_bone_index) or self.read_vec3(t_pawn + self.o.m_vOldOrigin)
                                bone_pos[2] -= self.downward_offset
                                tp, ty = self.calc_angle(my_pos, bone_pos)
                                if self.in_fov(pitch, yaw, tp, ty):
                                    target, target_pos = t_pawn, bone_pos
                                    min_dist = math.dist(my_pos, bone_pos)
                                else:
                                    self.target_id = None
                                    self.last_target_lost_time = time.time()
                            else:
                                self.target_id = None
                                self.last_target_lost_time = time.time()
                        else:
                            self.target_id = None
                            self.last_target_lost_time = time.time()

                # Find new target if none
                if not target:
                    if self.last_target_lost_time and time.time() - self.last_target_lost_time < self.target_switch_delay:
                        time.sleep(0.015)
                        continue
                    self.last_target_lost_time = 0

                    for i in range(self.max_entities):
                        ctrl_ent = self.get_entity(entity_list, i)
                        if not ctrl_ent or ctrl_ent == ctrl:
                            continue

                        pawn_ent_id = self.safe_read(ctrl_ent + self.o.m_hPlayerPawn) & 0x7FFF
                        pawn_ent = self.get_entity(entity_list, pawn_ent_id)
                        if not pawn_ent:
                            continue

                        hp = self.safe_read(pawn_ent + self.o.m_iHealth)
                        team = self.safe_read(pawn_ent + self.o.m_iTeamNum)
                        if hp <= 0 or (not self.DeathMatch and team == my_team):
                            continue

                        bone_pos = self.read_bone_pos(pawn_ent, self.target_bone_index) or self.read_vec3(pawn_ent + self.o.m_vOldOrigin)
                        bone_pos[2] -= self.downward_offset

                        p, y = self.calc_angle(my_pos, bone_pos)
                        if not self.in_fov(pitch, yaw, p, y):
                            continue

                        dist = math.dist(my_pos, bone_pos)
                        if dist < min_dist:
                            min_dist = dist
                            target, target_pos = pawn_ent, bone_pos
                            self.target_id = i

                if self.left_down:
                    if self.aim_start_time and time.time() - self.aim_start_time < self.aim_start_delay:
                        time.sleep(0.01)
                        continue

                    self.shots_fired += 1

                    if target and target_pos:
                        tp, ty = self.calc_angle(my_pos, target_pos)
                        cp = tp - recoil[0] * self.rcs_scale
                        cy = ty - recoil[1] * self.rcs_scale

                        smooth = max(0.05, min(self.smooth_base + random.uniform(-self.smooth_var, self.smooth_var), 0.3))
                        sp = pitch + self.angle_diff(cp, pitch) * smooth
                        sy = yaw + self.angle_diff(cy, yaw) * smooth
                        sp = self.add_noise(sp, 0.05)
                        sy = self.add_noise(sy, 0.05)
                        sp, sy = self.normalize(sp, sy)

                        self.pm.write_float(self.base + self.o.dwViewAngles, sp)
                        self.pm.write_float(self.base + self.o.dwViewAngles + 4, sy)

                    elif self.shots_fired >= self.stabilize_shots:
                        dp = (recoil[0] - self.last_punch[0]) * self.rcs_scale
                        dy = (recoil[1] - self.last_punch[1]) * self.rcs_scale
                        sp, sy = self.normalize(pitch - dp, yaw - dy)

                        rcs_smooth = max(0.07, min(self.rcs_smooth_base + random.uniform(-self.rcs_smooth_var, self.rcs_smooth_var), 0.35))
                        sp = self.lerp(pitch, sp, rcs_smooth)
                        sy = self.lerp(yaw, sy, rcs_smooth)
                        sp = self.add_noise(sp, 0.03)
                        sy = self.add_noise(sy, 0.03)

                        self.pm.write_float(self.base + self.o.dwViewAngles, sp)
                        self.pm.write_float(self.base + self.o.dwViewAngles + 4, sy)

                    self.last_punch = recoil
                else:
                    self.shots_fired = 0
                    self.last_punch = (0.0, 0.0)
                    self.aim_start_time = None

                time.sleep(0.007 + random.uniform(0, 0.006))

            except Exception as e:
                print(f"[!] Exception: {e}")
                time.sleep(0.5)

if __name__ == "__main__":
    AimbotRCS().run()
